import { ControllerManager } from './binding/controller';
import { RegisterElement } from './elements/registerAll';
//import { Navigate } from './system/navigate';
import { Loader } from './system/loader';
import { ElementsManager } from './binding/elements';

var html = document.getElementsByTagName('html')[0].childNodes;
var passBody = false;
for (var iel = 0; iel < html.length; iel++) {
    let child = html.item(iel);
    if (child.isElement()) {
        if (passBody) {
            child.style.display = 'none';
        }
        else {
            if (child.tagName == 'BODY')
                passBody = true;
        }
    }
}

Loader.getHtmlAjax('/view/layout.html')
    .then((value) => ElementsManager.ins.init(value));

ControllerManager.setResolver((name) => {
    let url = `/${name.replace('.', '/')}`;
    return Loader.getJs(url);
});

//Navigate.instance.onRoute((info) => {
//    return new Promise(async (e, r) => {
//        let urlHtml, urlJs;
//        switch(info.paths.length) {
//            case 0:
//                urlHtml = '/view/home/index.html';
//                urlJs = '/view/home/index';
//                break;
//            case 1:
//                urlHtml = `/view/${info.paths[0]}/index.html`;
//                urlJs = `/view/${info.paths[0]}/index`;
//                break;
//            default:
//                urlHtml = `/view/${info.paths[0]}/${info.paths[1]}.html`;
//                urlJs = `/view/${info.paths[0]}/${info.paths[1]}`;
//        }

//        let html = await Loader.getHtml(urlHtml);
//        let js = await Loader.getJs(urlJs);
//        let data = {
//            html: html,
//            ctr: js.default
//        }
//        e(data);
//    });
//});

RegisterElement();