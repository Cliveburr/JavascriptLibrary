"use strict";
const controller_1 = require('./controller');
class ElementsManager {
    constructor() {
        this.els = {};
    }
    static get ins() {
        if (!ElementsManager._ins)
            ElementsManager._ins = new ElementsManager();
        return ElementsManager._ins;
    }
    register(tagName, prototype) {
        this.els[tagName.toUpperCase()] = prototype;
        return this;
    }
    init(html) {
        this.compile(document.body, html);
    }
    compile(el, html) {
        let oldDisplay = el.style.display;
        el.style.display = 'none';
        el.innerHTML = html;
        this.compileNode(el);
        this.runAttachedCallback(el);
        el.style.display = oldDisplay;
    }
    compileInline(node) {
        this.compileNode(node);
        this.runAttachedCallback(node);
    }
    compileNode(node) {
        if (node.isElement() && this.els.hasOwnProperty(node.tagName)) {
            let tp = this.els[node.tagName];
            let anchor = new Anchor();
            let nel = new tp(anchor, node);
            anchor['$$RID'] = node['$$RID'];
            anchor.$$ELEMENT = nel;
            node.parentNode.replaceChild(anchor, node);
            nel.createdCallback();
        }
        else {
            if (node.isElement() && node.hasAttribute('nt-ctr')) {
                controller_1.ControllerManager.instance(node, node.getAttribute('nt-ctr'));
            }
            if (node.hasChildNodes()) {
                for (let i = 0; i < node.childNodes.length; i++) {
                    this.compileNode(node.childNodes.item(i));
                }
            }
        }
    }
    runAttachedCallback(node) {
        if (Anchor.isAnchor(node) && node.$$ELEMENT.attachedCallback) {
            node.$$ELEMENT.attachedCallback();
        }
        if (node.hasChildNodes()) {
            for (let ch of node.childNodes.toArray()) {
                this.runAttachedCallback(ch);
            }
        }
    }
}
exports.ElementsManager = ElementsManager;
class Anchor extends Text {
    constructor() {
        super();
        this.nds = [];
    }
    appendChild(node) {
        let last = this.nds.any() ? this.nds.last() : this;
        this.parentNode.insertBefore(node, last.nextSibling);
        this.nds.push(node);
        ElementsManager.ins.compileInline(node);
        return node;
    }
    insertBefore(ne, ref) {
        let i = this.nds.indexOf(ref);
        if (i > -1) {
            this.parentNode.insertBefore(ne, ref);
            this.nds.splice(i, 0, ne);
            ElementsManager.ins.compileInline(ne);
        }
        return ne;
    }
    clearChilds() {
        for (let ch of this.nds) {
            this.parentNode.removeChild(ch);
        }
        this.nds = [];
    }
    get childs() {
        return this.nds;
    }
    removeChild(node) {
        let i = this.nds.indexOf(node);
        if (i > -1) {
            this.parentNode.removeChild(node);
            this.nds.splice(i, 1);
        }
        return node;
    }
    static isAnchor(node) {
        return node instanceof Anchor;
    }
}
exports.Anchor = Anchor;
//# sourceMappingURL=elements.js.map