"use strict";
class Scope {
    constructor(el) {
        this.el = el;
        el['$$SCOPE'] = this;
    }
    set(data) {
        this.data = data;
        this.callOnScopeChilds(this.el, false);
    }
    callOnScopeChilds(el, me) {
        if (Scope.isOnScope(el)) {
            el.$$ONSCOPE(this.data);
        }
        if (Scope.isScope(el) && me)
            return;
        for (let i = 0; i < el.childNodes.length; i++) {
            this.callOnScopeChilds(el.childNodes.item(i), true);
        }
    }
    static isScope(node) {
        return typeof node.$$SCOPE !== 'undefined';
    }
    static isOnScope(node) {
        return typeof node.$$ONSCOPE !== 'undefined';
    }
    static setOnScope(node, onscope) {
        node['$$ONSCOPE'] = onscope;
    }
}
exports.Scope = Scope;
//# sourceMappingURL=scope.js.map