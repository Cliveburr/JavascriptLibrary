
export interface ScopeElement extends Node {
    $$SCOPE: Scope;
}

export interface OnScopeElement extends Node {
    $$ONSCOPE: OnScopeDelegate;
}

export interface OnScopeDelegate {
    (data: any): void;
}

export class Scope {
    public data: any;

    public constructor(
        private el: HTMLElement
    ) {
        el['$$SCOPE'] = this;
    }

    public set(data: any): void {
        this.data = data;
        this.callOnScopeChilds(this.el, false);
    }

    private callOnScopeChilds(el: Node, me: boolean): void {
        if (Scope.isOnScope(el)) {
            el.$$ONSCOPE(this.data);
        }
        if (Scope.isScope(el) && me)
            return;
        for (let i = 0; i < el.childNodes.length; i++) {
            this.callOnScopeChilds(el.childNodes.item(i), true);
        }
    }

    public static isScope(node: Node): node is ScopeElement {
        return typeof (<ScopeElement>node).$$SCOPE !== 'undefined';
    }

    public static isOnScope(node: Node): node is OnScopeElement {
        return typeof (<OnScopeElement>node).$$ONSCOPE !== 'undefined';
    }

    public static setOnScope(node: Node, onscope: OnScopeDelegate): void {
        node['$$ONSCOPE'] = onscope;
    }
}