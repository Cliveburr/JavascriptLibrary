﻿import { ControllerManager } from './controller';

export interface IElements {
    createdCallback(): void;
    attachedCallback(): void;
}

export interface IElementsType {
    new (anchor: Anchor, el: HTMLElement): IElements;
}

export class ElementsManager {
    private static _ins: ElementsManager;

    private els: { [tagName: string]: IElementsType } = {};

    private constructor() {
    }

    public static get ins(): ElementsManager {
        if (!ElementsManager._ins)
            ElementsManager._ins = new ElementsManager();
        return ElementsManager._ins;
    }

    public register(tagName: string, prototype: IElementsType): this {
        this.els[tagName.toUpperCase()] = prototype;
        return this;
    }

    public init(html: string): void {
        this.compile(document.body, html);
    }

    public compile(el: HTMLElement, html: string): void {
        let oldDisplay = el.style.display;
        el.style.display = 'none';
        el.innerHTML = html;
        this.compileNode(el);
        this.runAttachedCallback(el);
        el.style.display = oldDisplay;
    }

    public compileInline(node: Node): void {
        this.compileNode(node);
        this.runAttachedCallback(node);
    }

    private compileNode(node: Node): void {
        if (node.isElement() && this.els.hasOwnProperty(node.tagName)) {
            let tp = this.els[node.tagName];
            let anchor = new Anchor();
            let nel = new tp(anchor, node);
            anchor['$$RID'] = node['$$RID'];
            anchor.$$ELEMENT = nel;
            node.parentNode.replaceChild(anchor, node);
            nel.createdCallback();
        }
        else {
            if (node.isElement() && node.hasAttribute('nt-ctr')) {
                ControllerManager.instance(node, node.getAttribute('nt-ctr'));
            }
            if (node.hasChildNodes()) {
                for (let i = 0; i < node.childNodes.length; i++) {
                    this.compileNode(node.childNodes.item(i));
                }
            }
        }
    }

    private runAttachedCallback(node: Node): void {
        if (Anchor.isAnchor(node) && node.$$ELEMENT.attachedCallback) {
            node.$$ELEMENT.attachedCallback();
        }
        if (node.hasChildNodes()) {
            for (let ch of node.childNodes.toArray()) {
                this.runAttachedCallback(ch);
            }
        }
    }
}

export class Anchor extends Text {
    public $$ELEMENT: IElements;

    private nds: Array<Node>;

    public constructor() {
        super();
        this.nds = [];
    }

    public appendChild(node: Node): Node {
        let last = this.nds.any() ? this.nds.last() : this;
        this.parentNode.insertBefore(node, last.nextSibling);
        this.nds.push(node);
        ElementsManager.ins.compileInline(node);
        return node;
    }

    public insertBefore(ne: Node, ref: Node): Node {
        let i = this.nds.indexOf(ref);
        if (i > -1) {
            this.parentNode.insertBefore(ne, ref);
            this.nds.splice(i, 0, ne);
            ElementsManager.ins.compileInline(ne);
        }
        return ne;
    }

    public clearChilds(): void {
        for (let ch of this.nds) {
            this.parentNode.removeChild(ch);
        }
        this.nds = [];
    }

    public get childs(): Array<Node> {
        return this.nds;
    }

    public removeChild(node: Node): Node {
        let i = this.nds.indexOf(node);
        if (i > -1) {
            this.parentNode.removeChild(node);
            this.nds.splice(i, 1);
        }
        return node;
    }

    public static isAnchor(node: Node): node is Anchor {
        return node instanceof Anchor;
    }
}