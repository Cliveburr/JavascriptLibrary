"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator.throw(value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments)).next());
    });
};
class ControllerManager {
    static get(name) {
        return this._cls[name];
    }
    static set(name, cls) {
        this._cls[name] = cls;
    }
    static setResolver(resolve) {
        this._resolve = resolve;
    }
    static tryResolve(cls) {
        return __awaiter(this, void 0, void 0, function* () {
            return new Promise((e, r) => __awaiter(this, void 0, void 0, function* () {
                if (!this._resolve)
                    throw 'Controller manager not setted resolved!';
                let rCls = yield this._resolve(cls);
                if (rCls && rCls.default) {
                    this.set(cls, rCls.default);
                    e(rCls.default);
                }
                else {
                    r(`Controller '${cls}' not found!`);
                }
            }));
        });
    }
    static instance(el, ctr) {
        return __awaiter(this, void 0, void 0, function* () {
            let cls = ControllerManager.get(ctr);
            if (cls) {
                return new cls(el);
            }
            else {
                let cls = yield ControllerManager.tryResolve(ctr);
                return new cls(el);
            }
        });
    }
}
ControllerManager._cls = {};
exports.ControllerManager = ControllerManager;
//# sourceMappingURL=controller.js.map