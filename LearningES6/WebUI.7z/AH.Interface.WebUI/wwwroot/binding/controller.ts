
export interface IClassType {
    new (el: HTMLElement): Object;
}

export interface IClassDefault {
    default: IClassType;
}

export interface IResolve {
    (name: string): Promise<IClassDefault>;
}

export class ControllerManager {
    private static _cls: { [name: string]: IClassType } = {};
    private static _resolve: IResolve;

    public static get(name: string): IClassType {
        return this._cls[name];
    }

    public static set(name: string, cls: IClassType): void {
        this._cls[name] = cls;
    }

    public static setResolver(resolve: IResolve): void {
        this._resolve = resolve;
    }

    public static async tryResolve(cls: string): Promise<IClassType> {
        return new Promise<IClassType>(async (e, r) => {
            if (!this._resolve)
                throw 'Controller manager not setted resolved!';
            let rCls = await this._resolve(cls);
            if (rCls && rCls.default) {
                this.set(cls, rCls.default);
                e(rCls.default);
            }
            else {
                r(`Controller '${cls}' not found!`);
            }
        });
    }

    public static async instance(el: HTMLElement, ctr: string): Promise<Object> {
        let cls = ControllerManager.get(ctr);
        if (cls) {
            return new cls(el);
        }
        else {
            let cls = await ControllerManager.tryResolve(ctr);
            return new cls(el);
        }
    }
}