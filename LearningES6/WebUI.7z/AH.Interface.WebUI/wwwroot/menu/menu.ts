import * as Models from '../elements/models';
import { Scope } from '../binding/scope';

export interface IMenuModel {
    oneText: Models.ISpanModel;
    oItems: Array<IMenuOitems>;
    items: Array<Models.ILinkModel>;
    oneitem: Models.ILinkModel;
}

export interface IMenuOitems {
    text: Models.ISpanModel;
}

export default class Menu {
    public scope: Scope;

    public constructor(
        public el: HTMLElement) {
        this.scope = new Scope(el);
        setTimeout(this.load.bind(this), 100);
    }

    private load(): void {
        let model: IMenuModel = {
            oneText: {
                text: 'oneText label'
            },
            oItems: [
                { text: { text: 'oItem text 0' } },
                { text: { text: 'oItem text 1' } },
                { text: { text: 'oItem text 2' } },
                { text: { text: 'oItem text 3' } }
            ],
            items: [
                { text: 'Home', url: '/home' },
                { text: 'Customer', url: '/customer' },
                { text: 'About', url: '/home/about' }
            ],
            oneitem: { text: 'Home1', url: '/home' }
        };
        this.scope.set(model);
    }
}