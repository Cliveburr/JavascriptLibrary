"use strict";
const scope_1 = require('../binding/scope');
class Menu {
    constructor(el) {
        this.el = el;
        this.scope = new scope_1.Scope(el);
        setTimeout(this.load.bind(this), 100);
    }
    load() {
        let model = {
            oneText: {
                text: 'oneText label'
            },
            oItems: [
                { text: { text: 'oItem text 0' } },
                { text: { text: 'oItem text 1' } },
                { text: { text: 'oItem text 2' } },
                { text: { text: 'oItem text 3' } }
            ],
            items: [
                { text: 'Home', url: '/home' },
                { text: 'Customer', url: '/customer' },
                { text: 'About', url: '/home/about' }
            ],
            oneitem: { text: 'Home1', url: '/home' }
        };
        this.scope.set(model);
    }
}
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = Menu;
//# sourceMappingURL=menu.js.map