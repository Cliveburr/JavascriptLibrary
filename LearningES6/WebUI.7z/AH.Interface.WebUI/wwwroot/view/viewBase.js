"use strict";
class ViewBase {
    //public abstract attachedCallback(): void;
    //public abstract detachedCallback(): void;
    get model() { return this._model; }
    setModel(scope) {
        let views = document.getElementsByTagName('nt-view');
        if (views.length != 1)
            throw 'Invalid numbers of nt-view!';
        let view = views.item(0);
        view.setScope(scope);
        this._model = scope;
    }
}
exports.ViewBase = ViewBase;
//# sourceMappingURL=viewBase.js.map