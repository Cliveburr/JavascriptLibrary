"use strict";
const viewBase_1 = require('../viewBase');
const observer_1 = require('../../system/observer');
class HomeIndex extends viewBase_1.ViewBase {
    constructor() {
        super();
    }
    createdCallback() {
        this.setModel({
            btOne: {
                text: 'Name:',
                placeholder: 'testing...'
            },
            action: {
                text: 'clica',
                onclick: this.action_onclick.bind(this)
            },
            names: observer_1.ObserverArray([])
        });
    }
    action_onclick(ev) {
        //alert(this.model.btOne.value);
        let nName = {
            sp: {
                text: observer_1.Observer(this.model.btOne.value),
                onclick: () => this.sp_onclick2(nName)
            }
        };
        this.model.names.push(nName);
    }
    sp_onclick2(item) {
        let h = this.model.names.indexOf(item);
        let nName = {
            sp: {
                text: '-- insert --'
            }
        };
        this.model.names.insert(h, nName);
    }
    sp_onclick(model) {
        //let tx = model.text as IObserver<string>;
        //tx(tx() + '-1-');
        //this.model.names.remove(model.parent);
    }
}
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = HomeIndex;
console.log('home');
//# sourceMappingURL=index.js.map