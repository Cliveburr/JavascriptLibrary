
export default class AboutIndex {
    
}

console.log('about');