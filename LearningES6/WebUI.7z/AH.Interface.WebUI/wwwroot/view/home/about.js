"use strict";
class AboutIndex {
}
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = AboutIndex;
console.log('about');
//# sourceMappingURL=about.js.map