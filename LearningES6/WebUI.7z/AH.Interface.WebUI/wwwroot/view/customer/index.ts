
export default class CustomerIndex {
    
}

console.log('customer');