"use strict";
class CustomerIndex {
}
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = CustomerIndex;
console.log('customer');
//# sourceMappingURL=index.js.map