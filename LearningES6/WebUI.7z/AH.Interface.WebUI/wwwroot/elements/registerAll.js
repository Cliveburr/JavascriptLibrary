"use strict";
const elements_1 = require('../binding/elements');
const linkElement2_1 = require('./linkElement2');
//import { InputElement } from './inputElement';
//import { ButtonElement } from './buttonElement';
//import { SpanElement } from './spanElement';
//import { ControllerElement } from './controllerElement';
const arrayElement_1 = require('./arrayElement');
//import { ViewElement } from './viewElement';
//import { TemplateElement } from './templateElement'; 
//function regs(els: { [tag: string]: webcomponents.CustomElementInit }) {
//    for (let el in els) {
//        document.registerElement(el, els[el]);
//    }
//}
function RegisterElement() {
    //regs({
    //    'nt-link': LinkElement,
    //    'nt-input': InputElement,
    //    'nt-button': ButtonElement,
    //    'nt-span': SpanElement,
    //    'nt-controller': ControllerElement,
    //    'nt-array': ArrayElement,
    //    'nt-view': ViewElement,
    //    'nt-template': TemplateElement
    //});
    elements_1.ElementsManager.ins
        .register('nt-link', linkElement2_1.LinkElement)
        .register('nt-array', arrayElement_1.ArrayElement);
}
exports.RegisterElement = RegisterElement;
//# sourceMappingURL=registerAll.js.map