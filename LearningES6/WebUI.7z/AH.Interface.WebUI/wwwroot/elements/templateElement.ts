﻿import { BaseElement } from './baseElement';
import { Loader } from '../system/loader';

export class TemplateElement extends BaseElement<null> {

    public createdCallback() {
        let src = this.attributes.getNamedItem('src');
        if (src)
            this.loadSrc(src.value);
    }

    private loadSrc(src: string): void {
        Loader
            .getHtmlAjax(src)
            .then((html) => this.innerHTML = html);
    }
}