"use strict";
class BaseElement extends HTMLElement {
    //private _scopeCallBack: Array<(scope: any) => void>;
    scopeInitialize() {
        this.isScope = true;
        //this._scopeCallBack = [];
    }
    setScope(scope) {
        if (!this.isScope)
            throw `Need to initialize the scope before set!`;
        this.scope = scope;
        //this.callOnScope();
        this.callOnScopeChilds(this, false);
    }
    // private callOnScope(): void {
    //     for (let cb of this._scopeCallBack) {
    //         cb(this.scope);
    //     }
    // }
    callOnScopeChilds(el, me) {
        if (el['onScope']) {
            el['onScope'](this.scope);
        }
        if (el['isScope'] && me)
            return;
        for (let i = 0; i < el.childNodes.length; i++) {
            this.callOnScopeChilds(el.childNodes.item(i), true);
        }
    }
    checkScope() {
        if (this['onScope'] && this.parentNode) {
            let parentScope = this.getClosedScope(this.parentNode);
            if (parentScope) {
                this['onScope'](parentScope.scope);
            }
        }
    }
    // public onScope(callBack: (scope: any) => void): void {
    //     if (this.isScope) {
    //         this._scopeCallBack.push(callBack);
    //         if (this.scope) {
    //             callBack(this.scope);
    //         }
    //     }
    //     else {
    //         let parentScope = this.getClosedScope(this.parentElement);
    //         if (parentScope) {
    //             parentScope.onScope(callBack);
    //         }
    //         else {
    //             throw `None scope has found!`;
    //         }
    //     }
    // }
    getClosedScope(el) {
        if (el['isScope']) {
            return el;
        }
        else {
            if (el.parentNode) {
                return this.getClosedScope(el.parentNode);
            }
            else {
                return null;
            }
        }
    }
    getModel() {
        let am = this.attributes.getNamedItem('model');
        if (!am)
            return undefined;
        let ns = this.mountNamespace();
        let ps = ns.split('.');
        let so = this.getClosedScope(this.parentNode);
        let tr = so.scope;
        for (let p of ps) {
            if (!tr)
                return undefined;
            if (this.isObserver(tr) || this.isObserverArray(tr)) {
                tr = tr()[p];
            }
            else {
                tr = tr[p];
            }
        }
        return tr;
    }
    mountNamespace() {
        let tr = '';
        let te = this;
        while (te) {
            if (te.hasOwnProperty('isScope')) {
                break;
            }
            let am = te.attributes.getNamedItem('model');
            if (am && am.value != '') {
                tr = am.value + '.' + tr;
            }
            if (te.hasOwnProperty('$$RID')) {
                tr = te['$$RID'] + '.' + tr;
            }
            te = te.parentNode;
        }
        return tr.endsWith('.') ?
            tr.substr(0, tr.length - 1) :
            tr;
    }
    isObserver(model) {
        return model.isObserver;
    }
    isObserverArray(model) {
        return model.isObserverArray;
    }
}
exports.BaseElement = BaseElement;
//# sourceMappingURL=baseElement.js.map