"use strict";
const baseElement_1 = require('./baseElement');
const loader_1 = require('../system/loader');
class TemplateElement extends baseElement_1.BaseElement {
    createdCallback() {
        let src = this.attributes.getNamedItem('src');
        if (src)
            this.loadSrc(src.value);
    }
    loadSrc(src) {
        loader_1.Loader
            .getHtmlAjax(src)
            .then((html) => this.innerHTML = html);
    }
}
exports.TemplateElement = TemplateElement;
//# sourceMappingURL=templateElement.js.map