"use strict";
const baseElement_1 = require('./baseElement');
class ViewElement extends baseElement_1.BaseElement {
    createdCallback() {
        this.scopeInitialize();
    }
}
exports.ViewElement = ViewElement;
//# sourceMappingURL=viewElement.js.map