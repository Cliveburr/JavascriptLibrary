export { IButtonModel } from './buttonElement';
export { IInputModel } from './inputElement';
export { ISpanModel } from './spanElement';
export { ILinkModel } from './linkElement';