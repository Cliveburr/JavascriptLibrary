"use strict";
const scope_1 = require('../binding/scope');
class BaseElement {
    constructor(anchor, base) {
        this.anchor = anchor;
        this.base = base;
    }
    setOnScope() {
        scope_1.Scope.setOnScope(this.anchor, this.onScope.bind(this));
    }
    onScope(data) {
    }
    checkScope() {
        let parentScope = this.getClosedScope(this.anchor);
        if (parentScope) {
            this.onScope(parentScope.data);
        }
    }
    getModel() {
        let am = this.base.attributes.getNamedItem('model');
        if (!am)
            return undefined;
        let ns = this.mountNamespace();
        let ps = ns.split('.');
        let so = this.getClosedScope(this.anchor);
        let tr = so.data;
        for (let p of ps) {
            if (!tr)
                return undefined;
            if (this.isObserver(tr) || this.isObserverArray(tr)) {
                tr = tr()[p];
            }
            else {
                tr = tr[p];
            }
        }
        return tr;
    }
    getClosedScope(el) {
        if (scope_1.Scope.isScope(el)) {
            return el.$$SCOPE;
        }
        else {
            if (el.parentNode) {
                return this.getClosedScope(el.parentNode);
            }
            else {
                return null;
            }
        }
    }
    mountNamespace() {
        let tr = '';
        let te = this.anchor;
        while (te) {
            if (scope_1.Scope.isScope(te)) {
                break;
            }
            let am = te.attributes.getNamedItem('model');
            if (am && am.value != '') {
                tr = am.value + '.' + tr;
            }
            if (te.hasOwnProperty('$$RID')) {
                tr = te['$$RID'] + '.' + tr;
            }
            te = te.parentNode;
        }
        return tr.endsWith('.') ?
            tr.substr(0, tr.length - 1) :
            tr;
    }
    isObserver(model) {
        return model.isObserver;
    }
    isObserverArray(model) {
        return model.isObserverArray;
    }
}
exports.BaseElement = BaseElement;
//# sourceMappingURL=baseElement2.js.map