"use strict";
const baseElement_1 = require('./baseElement');
class ButtonElement extends baseElement_1.BaseElement {
    createdCallback() {
        let root = this.createShadowRoot();
        this._i = document.createElement('input');
        this._i.type = 'button';
        this._i.onclick = this._i_onclick.bind(this);
        root.appendChild(this._i);
    }
    onScope(data) {
        if (this.model = this.getModel()) {
            this._i.value = this.model.text;
        }
    }
    _i_onclick(ev) {
        this.model.onclick(this.model, this, ev);
    }
}
exports.ButtonElement = ButtonElement;
//# sourceMappingURL=buttonElement.js.map