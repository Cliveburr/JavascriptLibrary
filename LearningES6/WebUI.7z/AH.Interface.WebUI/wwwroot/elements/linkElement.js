"use strict";
const baseElement_1 = require('./baseElement');
class LinkElement extends baseElement_1.BaseElement {
    createdCallback() {
        let ine = this.innerHTML;
        this.innerHTML = '';
        //let root = this.createShadowRoot();
        this._a = document.createElement('a');
        this._a.addEventListener('click', this.a_onClick.bind(this));
        let sty = this.attributes.getNamedItem('class');
        if (sty) {
            this._a.className = sty.value;
            this.removeAttribute('class');
        }
        //root.appendChild(this._a);
        this.appendChild(this._a);
    }
    attachedCallback() {
        this.checkScope();
    }
    get href() { return this._a.href; }
    a_onClick(ev) {
        let typeAttr = this.attributes.getNamedItem('type');
        LinkManager.callOnClick(this, ev, typeAttr ? typeAttr.value : undefined);
        ev.preventDefault();
    }
    onScope(data) {
        if (this.model = this.getModel()) {
            this._a.innerText = this.model.text || '';
            this._a.href = this.model.url;
        }
    }
}
exports.LinkElement = LinkElement;
class LinkManager {
    static callOnClick(el, ev, type) {
        type = type || 'default';
        for (let onClick of LinkManager._onClicks[type]) {
            onClick(el, ev);
        }
    }
    static setOnClick(onClick, type) {
        type = type || 'default';
        if (!LinkManager._onClicks[type])
            LinkManager._onClicks[type] = [];
        LinkManager._onClicks[type].push(onClick);
    }
}
LinkManager._onClicks = {};
exports.LinkManager = LinkManager;
//# sourceMappingURL=linkElement.js.map