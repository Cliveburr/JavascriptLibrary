import { BaseElement } from './baseElement2';
import { IObserverArray, OnChangeType } from '../system/observer';

export class ArrayElement extends BaseElement<Array<any> | IObserverArray<any>> {
    private static _count: number = 0;

    private _index: number;

    public createdCallback(): void {
        this.setOnScope();
        this._index = ArrayElement._count++;
    }

    public attachedCallback(): void {
        if (!this.model)
            this.checkScope();
    }

    public onScope(data: any): void {
        if (this.model = this.getModel()) {
            if (this.isObserverArray(this.model)) {
                this.model.on(this.onModelChange.bind(this));
            }
            else {
                if (!Array.isArray(this.model))
                    throw `Only array can be the model of ArrayElement!`;
            }
            this.createElements();
        }
    }

    private createElements(): void {
        this.anchor.clearChilds();
        for (let it = 0; it < this.model.length; it++) {
            this.appendElement(it);
        }
    }

    private appendElement(id: number): void {
        let childs = this.base.innerHTML.parseHtml();
        for (let i = 0; i < childs.length; i++) {
            let nn = childs[i].cloneNode(true);
            nn['$$RID'] = id;
            this.anchor.appendChild(nn);
        }
    }

    private removeElement(id: number): void {
        let fd = 0;
        for (let i = 0; i < this.anchor.childs.length; i++) {
            let nn = this.anchor.childs[i];
            let rid = nn['$$RID'];
            if (fd == 0) {
                if (rid == id) {
                    this.anchor.removeChild(nn);
                    fd = 1;
                    i--;
                }
            }
            else if (fd == 1) {
                if (rid == id) {
                    this.anchor.removeChild(nn);
                    i--;
                }
                else {
                    nn['$$RID'] = --rid;
                    fd = 2;
                }
            }
            else {
                nn['$$RID'] = --rid;
            }
        }
    }

    private insertElement(id: number): void {
        let fd = true;
        for (let i = 0; i < this.anchor.childs.length; i++) {
            let oc = this.anchor.childs[i];
            let rid = oc['$$RID'];
            if (fd) {
                if (rid == id) {
                    oc['$$RID'] = ++rid;
                    let childs = this.base.innerHTML.parseHtml();
                    for (let ci = 0; ci < childs.length; ci++) {
                        let nn = childs[ci].cloneNode(true);
                        nn['$$RID'] = id;
                        this.anchor.insertBefore(nn, oc);
                        i++;
                    }
                    fd = false;
                }
            }
            else {
                oc['$$RID'] = ++rid;
            }
        }
        if (fd) {
            this.appendElement(id);
        }
    }

    private onModelChange(v: Array<any>, index: number, type: OnChangeType): void {
        let m = this.model as IObserverArray<any>;
        if (type == OnChangeType.add) {
            this.insertElement(index);
        }
        else if (type == OnChangeType.remove) {
            this.removeElement(index);
        }
        else {
            this.removeElement(index);
            this.insertElement(index);
        }
    }
}