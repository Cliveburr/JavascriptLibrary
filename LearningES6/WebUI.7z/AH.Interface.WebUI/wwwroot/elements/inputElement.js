"use strict";
const baseElement_1 = require('./baseElement');
var template = `<label><span></span><input type="text"></input></label>`;
class InputElement extends baseElement_1.BaseElement {
    createdCallback() {
        let root = this.createShadowRoot();
        root.innerHTML = template;
        this._s = root.querySelector('span');
        this._i = root.querySelector('input');
        this._i.onchange = this._i_onkeypress.bind(this);
    }
    onScope(data) {
        if (this.model = this.getModel()) {
            this._s.innerText = this.model.text || '';
            this._i.placeholder = this.model.placeholder;
        }
    }
    _i_onkeypress(ev) {
        this.model.value = this._i.value;
    }
}
exports.InputElement = InputElement;
//# sourceMappingURL=inputElement.js.map