"use strict";
const baseElement2_1 = require('./baseElement2');
const observer_1 = require('../system/observer');
class ArrayElement extends baseElement2_1.BaseElement {
    createdCallback() {
        this.setOnScope();
        this._index = ArrayElement._count++;
    }
    attachedCallback() {
        if (!this.model)
            this.checkScope();
    }
    onScope(data) {
        if (this.model = this.getModel()) {
            if (this.isObserverArray(this.model)) {
                this.model.on(this.onModelChange.bind(this));
            }
            else {
                if (!Array.isArray(this.model))
                    throw `Only array can be the model of ArrayElement!`;
            }
            this.createElements();
        }
    }
    createElements() {
        this.anchor.clearChilds();
        for (let it = 0; it < this.model.length; it++) {
            this.appendElement(it);
        }
    }
    appendElement(id) {
        let childs = this.base.innerHTML.parseHtml();
        for (let i = 0; i < childs.length; i++) {
            let nn = childs[i].cloneNode(true);
            nn['$$RID'] = id;
            this.anchor.appendChild(nn);
        }
    }
    removeElement(id) {
        let fd = 0;
        for (let i = 0; i < this.anchor.childs.length; i++) {
            let nn = this.anchor.childs[i];
            let rid = nn['$$RID'];
            if (fd == 0) {
                if (rid == id) {
                    this.anchor.removeChild(nn);
                    fd = 1;
                    i--;
                }
            }
            else if (fd == 1) {
                if (rid == id) {
                    this.anchor.removeChild(nn);
                    i--;
                }
                else {
                    nn['$$RID'] = --rid;
                    fd = 2;
                }
            }
            else {
                nn['$$RID'] = --rid;
            }
        }
    }
    insertElement(id) {
        let fd = true;
        for (let i = 0; i < this.anchor.childs.length; i++) {
            let oc = this.anchor.childs[i];
            let rid = oc['$$RID'];
            if (fd) {
                if (rid == id) {
                    oc['$$RID'] = ++rid;
                    let childs = this.base.innerHTML.parseHtml();
                    for (let ci = 0; ci < childs.length; ci++) {
                        let nn = childs[ci].cloneNode(true);
                        nn['$$RID'] = id;
                        this.anchor.insertBefore(nn, oc);
                        i++;
                    }
                    fd = false;
                }
            }
            else {
                oc['$$RID'] = ++rid;
            }
        }
        if (fd) {
            this.appendElement(id);
        }
    }
    onModelChange(v, index, type) {
        let m = this.model;
        if (type == observer_1.OnChangeType.add) {
            this.insertElement(index);
        }
        else if (type == observer_1.OnChangeType.remove) {
            this.removeElement(index);
        }
        else {
            this.removeElement(index);
            this.insertElement(index);
        }
    }
}
ArrayElement._count = 0;
exports.ArrayElement = ArrayElement;
//# sourceMappingURL=arrayElement.js.map