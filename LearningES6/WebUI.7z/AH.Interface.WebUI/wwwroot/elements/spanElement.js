"use strict";
const baseElement_1 = require('./baseElement');
class SpanElement extends baseElement_1.BaseElement {
    createdCallback() {
        let root = this.createShadowRoot();
        this._s = document.createElement('span');
        root.appendChild(this._s);
    }
    attachedCallback() {
        this.checkScope();
    }
    onScope(data) {
        if (this.model = this.getModel())
            this.refresh();
    }
    refresh() {
        if (this.isObserver(this.model.text)) {
            this.model.text.on((v) => this._s.innerText = v || '');
            this._s.innerText = this.model.text() || '';
        }
        else {
            this._s.innerText = this.model.text || '';
        }
        if (this.model.onclick)
            this._s.onclick = this._s_onclick.bind(this);
    }
    _s_onclick(ev) {
        this.model.onclick(this.model, this, ev);
    }
}
exports.SpanElement = SpanElement;
//# sourceMappingURL=spanElement.js.map