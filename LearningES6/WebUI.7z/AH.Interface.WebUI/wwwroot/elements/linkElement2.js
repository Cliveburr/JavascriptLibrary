"use strict";
const baseElement2_1 = require('./baseElement2');
class LinkElement extends baseElement2_1.BaseElement {
    createdCallback() {
        this.setOnScope();
        this._a = document.createElement('a');
        let sty = this.base.attributes.getNamedItem('class');
        if (sty) {
            this._a.className = sty.value;
        }
        this.anchor.appendChild(this._a);
        this.checkScope();
    }
    attachedCallback() {
    }
    onScope(data) {
        if (this.model = this.getModel()) {
            this._a.innerText = this.model.text || '';
            this._a.href = this.model.url;
        }
    }
}
exports.LinkElement = LinkElement;
//# sourceMappingURL=linkElement2.js.map