﻿import { IElements, Anchor } from '../binding/elements';
import { Scope } from '../binding/scope';
import { IObserver, IObserverArray } from '../system/observer';

export abstract class BaseElement<T> implements IElements {
    public model: T;

    public constructor(
        protected anchor: Anchor,
        protected base: HTMLElement) {
    }

    public abstract createdCallback(): void;
    public abstract attachedCallback(): void;

    protected setOnScope(): void {
        Scope.setOnScope(this.anchor, this.onScope.bind(this));
    }

    public onScope(data: any): void {
    }

    public checkScope(): void {
        let parentScope = this.getClosedScope(this.anchor);
        if (parentScope) {
            this.onScope(parentScope.data);
        }
    }

    public getModel(): T {
        let am = this.base.attributes.getNamedItem('model');
        if (!am)
            return undefined;
        let ns = this.mountNamespace();
        let ps = ns.split('.');
        let so = this.getClosedScope(this.anchor);
        let tr = so.data;
        for (let p of ps) {
            if (!tr)
                return undefined;
            if (this.isObserver(tr) || this.isObserverArray(tr)) {
                tr = tr()[p];
            }
            else {
                tr = tr[p];
            }
        }
        return tr;
    }

    private getClosedScope(el: Node): Scope {
        if (Scope.isScope(el)) {
            return el.$$SCOPE;
        }
        else {
            if (el.parentNode) {
                return this.getClosedScope(el.parentNode);
            }
            else {
                return null;
            }
        }
    }

    private mountNamespace(): string {
        let tr = '';
        let te = this.anchor as Node;
        while (te) {
            if (Scope.isScope(te)) {
                break;
            }
            let am = te.attributes.getNamedItem('model');
            if (am && am.value != '') {
                tr = am.value + '.' + tr;
            }
            if (te.hasOwnProperty('$$RID')) {
                tr = te['$$RID'] + '.' + tr;
            }
            te = te.parentNode;
        }
        return tr.endsWith('.') ?
            tr.substr(0, tr.length - 1) :
            tr;
    }

    public isObserver<U>(model: U | IObserver<U>): model is IObserver<U> {
        return (<IObserver<U>>model).isObserver;
    }

    public isObserverArray<U>(model: U | IObserverArray<U>): model is IObserverArray<U> {
        return (<IObserverArray<U>>model).isObserverArray;
    }
}