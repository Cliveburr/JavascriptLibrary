import { ElementsManager } from '../binding/elements';
import { LinkElement } from './linkElement2';
//import { InputElement } from './inputElement';
//import { ButtonElement } from './buttonElement';
//import { SpanElement } from './spanElement';
//import { ControllerElement } from './controllerElement';
import { ArrayElement } from './arrayElement';
//import { ViewElement } from './viewElement';
//import { TemplateElement } from './templateElement'; 

//function regs(els: { [tag: string]: webcomponents.CustomElementInit }) {
//    for (let el in els) {
//        document.registerElement(el, els[el]);
//    }
//}

export function RegisterElement(): void {
    //regs({
    //    'nt-link': LinkElement,
    //    'nt-input': InputElement,
    //    'nt-button': ButtonElement,
    //    'nt-span': SpanElement,
    //    'nt-controller': ControllerElement,
    //    'nt-array': ArrayElement,
    //    'nt-view': ViewElement,
    //    'nt-template': TemplateElement
    //});

    ElementsManager.ins
        .register('nt-link', LinkElement)
        .register('nt-array', ArrayElement);
}