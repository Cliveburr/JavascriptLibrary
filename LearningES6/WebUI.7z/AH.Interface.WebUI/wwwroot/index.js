"use strict";
const controller_1 = require('./binding/controller');
const registerAll_1 = require('./elements/registerAll');
//import { Navigate } from './system/navigate';
const loader_1 = require('./system/loader');
const elements_1 = require('./binding/elements');
var html = document.getElementsByTagName('html')[0].childNodes;
var passBody = false;
for (var iel = 0; iel < html.length; iel++) {
    let child = html.item(iel);
    if (child.isElement()) {
        if (passBody) {
            child.style.display = 'none';
        }
        else {
            if (child.tagName == 'BODY')
                passBody = true;
        }
    }
}
loader_1.Loader.getHtmlAjax('/view/layout.html')
    .then((value) => elements_1.ElementsManager.ins.init(value));
controller_1.ControllerManager.setResolver((name) => {
    let url = `/${name.replace('.', '/')}`;
    return loader_1.Loader.getJs(url);
});
//Navigate.instance.onRoute((info) => {
//    return new Promise(async (e, r) => {
//        let urlHtml, urlJs;
//        switch(info.paths.length) {
//            case 0:
//                urlHtml = '/view/home/index.html';
//                urlJs = '/view/home/index';
//                break;
//            case 1:
//                urlHtml = `/view/${info.paths[0]}/index.html`;
//                urlJs = `/view/${info.paths[0]}/index`;
//                break;
//            default:
//                urlHtml = `/view/${info.paths[0]}/${info.paths[1]}.html`;
//                urlJs = `/view/${info.paths[0]}/${info.paths[1]}`;
//        }
//        let html = await Loader.getHtml(urlHtml);
//        let js = await Loader.getJs(urlJs);
//        let data = {
//            html: html,
//            ctr: js.default
//        }
//        e(data);
//    });
//});
registerAll_1.RegisterElement();
//# sourceMappingURL=index.js.map