"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator.throw(value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments)).next());
    });
};
const ajax_1 = require('./ajax');
class Loader {
    static getJs(url) {
        return __awaiter(this, void 0, void 0, function* () {
            return new Promise((e, r) => {
                R(url, (err, cls) => {
                    if (err) {
                        r(err);
                    }
                    else {
                        e(cls);
                    }
                });
            });
        });
    }
    static getHtml(url) {
        return __awaiter(this, void 0, void 0, function* () {
            return new Promise((e, r) => {
                let link = document.createElement('link');
                link.rel = 'import';
                link.href = url;
                link.onload = () => {
                    let tmp = link.import.head.getElementsByTagName('template');
                    let html = tmp.length > 0 ?
                        tmp.item(0).innerHTML :
                        link.import.body.innerHTML;
                    document.head.removeChild(link);
                    e(html);
                };
                document.head.appendChild(link);
            });
        });
    }
    static getHtmlAjax(url) {
        return __awaiter(this, void 0, void 0, function* () {
            return ajax_1.Ajax.call(url, null, 'GET', {
                headers: {
                    'Content-type': 'text/html'
                }
            });
        });
    }
}
exports.Loader = Loader;
//# sourceMappingURL=loader.js.map