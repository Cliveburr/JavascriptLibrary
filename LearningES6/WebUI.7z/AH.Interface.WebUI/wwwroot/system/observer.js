"use strict";
function Observer(value) {
    let o = new Observable(value);
    let t = o.value.bind(o);
    Object.defineProperties(t, {
        'isObserver': {
            enumerable: false,
            get: () => { return true; }
        },
        'on': {
            enumerable: false,
            value: o.on.bind(o)
        },
        'off': {
            enumerable: false,
            value: o.off.bind(o)
        }
    });
    return t;
}
exports.Observer = Observer;
class Observable {
    constructor(_v) {
        this._v = _v;
        this._hs = [];
    }
    on(handle) {
        this._hs.push(handle);
    }
    off(handle) {
        let i = this._hs.indexOf(handle);
        if (i > -1)
            this._hs.splice(i, 1);
    }
    value(value) {
        if (typeof value != 'undefined') {
            this._v = value;
            this.notify();
        }
        return this._v;
    }
    notify() {
        for (let h of this._hs) {
            h(this._v);
        }
    }
}
exports.Observable = Observable;
(function (OnChangeType) {
    OnChangeType[OnChangeType["change"] = 0] = "change";
    OnChangeType[OnChangeType["add"] = 1] = "add";
    OnChangeType[OnChangeType["remove"] = 2] = "remove";
})(exports.OnChangeType || (exports.OnChangeType = {}));
var OnChangeType = exports.OnChangeType;
function ObserverArray(value) {
    let o = new ObservableArray(value);
    let t = o.value.bind(o);
    Object.defineProperties(t, {
        'isObserverArray': {
            enumerable: false,
            get: () => { return true; }
        },
        'on': {
            enumerable: false,
            value: o.on.bind(o)
        },
        'off': {
            enumerable: false,
            value: o.off.bind(o)
        },
        'length': {
            enumerable: false,
            get: o.length.bind(o)
        },
        'push': {
            enumerable: false,
            value: o.push.bind(o)
        },
        'pop': {
            enumerable: false,
            value: o.pop.bind(o)
        },
        'shift': {
            enumerable: false,
            value: o.shift.bind(o)
        },
        'unshift': {
            enumerable: false,
            value: o.unshift.bind(o)
        },
        'remove': {
            enumerable: false,
            value: o.remove.bind(o)
        },
        'insert': {
            enumerable: false,
            value: o.insert.bind(o)
        },
        'indexOf': {
            enumerable: false,
            value: o.indexOf.bind(o)
        }
    });
    return t;
}
exports.ObserverArray = ObserverArray;
class ObservableArray {
    constructor(_v) {
        this._v = _v;
        this._hs = [];
        this.prepare();
    }
    on(handle) {
        this._hs.push(handle);
    }
    off(handle) {
        let i = this._hs.indexOf(handle);
        if (i > -1)
            this._hs.splice(i, 1);
    }
    value(value) {
        if (typeof value != 'undefined') {
            this._v = value;
            this.prepare();
            this.notify(-1, OnChangeType.add);
        }
        return this._p;
    }
    notify(index, type) {
        for (let h of this._hs) {
            h(this._v, index, type);
        }
    }
    prepare() {
        if (!Array.isArray(this._v))
            throw 'The value of ObserverArray must be Array!';
        this._p = {};
        for (var i = 0; i < this._v.length; i++) {
            this.setArrayItem(i);
        }
    }
    setArrayItem(index) {
        Object.defineProperty(this._p, index.toString(), {
            configurable: true,
            enumerable: true,
            get: () => {
                return this._v[index];
            },
            set: (val) => {
                this._v[index] = val;
                this.notify(index, OnChangeType.change);
            }
        });
    }
    clearArrayItem(count) {
        for (var i = 0; i < count; i++) {
            let index = this._v.length - i;
            Object.defineProperty(this._p, index.toString(), {
                configurable: true,
                enumerable: true,
                writable: true,
                value: 1
            });
            delete this._p[index];
        }
    }
    length() {
        return this._v.length;
    }
    push(...items) {
        let bef = this._v.length;
        let val = Array.prototype.push.apply(this._v, items);
        if (items.length > 0) {
            for (let a = bef; a < bef + items.length; a++) {
                this.setArrayItem(a);
            }
            for (let a = bef; a < bef + items.length; a++) {
                this.notify(a, OnChangeType.add);
            }
        }
        return val;
    }
    pop() {
        this.notify(this._v.length - 1, OnChangeType.remove);
        let val = Array.prototype.pop.apply(this._v);
        this.clearArrayItem(1);
        return val;
    }
    shift() {
        this.notify(0, OnChangeType.remove);
        let val = Array.prototype.shift.apply(this._v);
        this.clearArrayItem(1);
        return val;
    }
    unshift(...items) {
        let bef = this._v.length;
        let val = Array.prototype.unshift.apply(this._v, items);
        if (items.length > 0) {
            for (let a = bef; a < bef + items.length; a++) {
                this.setArrayItem(a);
            }
            for (let a = 0; a < items.length; a++) {
                this.notify(a, OnChangeType.add);
            }
        }
        return val;
    }
    remove(item) {
        for (let i = 0; i < this._v.length; i++) {
            if (item === this._v[i]) {
                this.notify(i, OnChangeType.remove);
                let val = this._v.splice(i, 1)[0];
                this.clearArrayItem(1);
                return val;
            }
        }
        return null;
    }
    insert(index, ...items) {
        let bef = this._v.length;
        Array.prototype.splice.apply(this._v, [index, 0].concat(items));
        if (items.length > 0) {
            for (let a = bef; a < bef + items.length; a++) {
                this.setArrayItem(a);
            }
            for (let a = index; a < index + items.length; a++) {
                this.notify(a, OnChangeType.add);
            }
        }
        return this._v.length;
    }
    indexOf(item, fromIndex) {
        return this._v.indexOf(item, fromIndex);
    }
}
exports.ObservableArray = ObservableArray;
//# sourceMappingURL=observer.js.map