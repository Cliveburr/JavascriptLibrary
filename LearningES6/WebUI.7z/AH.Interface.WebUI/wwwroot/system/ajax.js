"use strict";
var defaultConfigs = {
    async: true
};
class Ajax {
    static call(url, data, method, configs) {
        return new Promise((e, r) => {
            configs = configs || defaultConfigs;
            var client = new XMLHttpRequest();
            client.onreadystatechange = (ev) => {
                if (client.readyState === client.DONE) {
                    if (client.status === 200) {
                        e(client.responseText);
                    }
                    else {
                        r(client.statusText);
                    }
                }
            };
            client.onerror = () => {
                r(client.statusText);
            };
            client.open(method, url, configs.async || defaultConfigs.async, configs.user || defaultConfigs.user, configs.password || defaultConfigs.password);
            let headers = configs.headers || defaultConfigs.headers;
            if (headers) {
                for (let head in headers) {
                    client.setRequestHeader(head, headers[head]);
                }
            }
            client.send(data);
        });
    }
}
exports.Ajax = Ajax;
//# sourceMappingURL=ajax.js.map