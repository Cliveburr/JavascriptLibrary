"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator.throw(value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments)).next());
    });
};
const linkElement_1 = require('../elements/linkElement');
class Navigate {
    constructor() {
        this._store = {};
        linkElement_1.LinkManager.setOnClick(this.link_onClick.bind(this));
        setTimeout(this.start.bind(this), 1);
    }
    static get instance() {
        if (!Navigate._instance) {
            Navigate._instance = new Navigate();
        }
        return Navigate._instance;
    }
    link_onClick(el, ev) {
        this.to(el.href);
    }
    start() {
        window.addEventListener('popstate', this.popstate.bind(this));
        this.to(window.location.pathname);
    }
    onRoute(resolve) {
        this._onRoute = resolve;
        return this;
    }
    onPreRoute(preRoute) {
        this._preRoute = preRoute;
        return this;
    }
    popstate(ev) {
        this.load(ev.state.url, ev.state.title);
    }
    to(url, title) {
        // atualizar o state
        if (this._currentCtr) {
            this.getState();
            window.history.pushState({ url, title }, title, url);
        }
        this.load(url, title);
    }
    getState() {
        let store = this._store[window.location.pathname];
        let view = document.getElementsByTagName('nt-view');
        if (view.length > 0) {
            store.htmlState = [];
            for (let i = 0; i < view.item(0).childNodes.length; i++) {
                store.htmlState.push(view.item(0).childNodes.item(i));
            }
        }
        store.ctrState = this._currentCtr;
    }
    load(url, title) {
        return __awaiter(this, void 0, void 0, function* () {
            // gera o info
            let info = {
                url: url,
                title: title,
                href: window.location.href,
                paths: window.location.pathname.split('/').filter(p => p !== ''),
                query: window.location.search
            };
            // fazer o call pre route
            if (this._preRoute)
                this._preRoute(info);
            // checar se a o path já é conhecido
            if (this._store[window.location.pathname]) {
                this.processRoute(this._store[window.location.pathname], info);
            }
            else {
                // se não for conhecido
                // chamar o onroute para buscar o content e diversos loads
                let data = yield this._onRoute(info);
                this._store[window.location.pathname] = data;
                this.processRoute(data, info);
            }
        });
    }
    processRoute(data, info) {
        if (!data.ctr)
            throw 'Route controller not found!';
        // fazer o call da route unload
        if (this._currentCtr && this._currentCtr.detachedCallback)
            this._currentCtr.detachedCallback();
        if (data.ctrState) {
            this._currentCtr = data.ctrState;
            this.setState(data.htmlState);
        }
        else {
            this._currentCtr = new data.ctr();
            this.render(data.html);
            if (this._currentCtr && this._currentCtr.createdCallback)
                this._currentCtr.createdCallback();
        }
        if (this._currentCtr && this._currentCtr.attachedCallback)
            this._currentCtr.attachedCallback();
    }
    render(html) {
        let view = document.getElementsByTagName('nt-view');
        if (view.length > 0) {
            view.item(0).innerHTML = html;
        }
    }
    setState(childs) {
        let view = document.getElementsByTagName('nt-view');
        if (view.length > 0) {
            view.item(0).innerHTML = '';
            for (let child of childs) {
                view.item(0).appendChild(child);
            }
        }
    }
}
exports.Navigate = Navigate;
//# sourceMappingURL=navigate.js.map