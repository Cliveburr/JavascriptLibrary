﻿
export interface IAjaxConfig {
    async?: boolean;
    headers?: { [name: string]: string };
    user?: string;
    password?: string;
}

var defaultConfigs: IAjaxConfig = {
    async: true
};

export class Ajax {
    public static call(url: string, data: any, method: string, configs?: IAjaxConfig): Promise<string> {
        return new Promise<string>((e, r) => {
            configs = configs || defaultConfigs;
            var client = new XMLHttpRequest();

            client.onreadystatechange = (ev): void => {
                if (client.readyState === client.DONE) {
                    if (client.status === 200) {
                        e(client.responseText);
                    } else {
                        r(client.statusText);
                    }
                }
            };

            client.onerror = (): void => {
                r(client.statusText);
            };

            client.open(method, url,
                configs.async || defaultConfigs.async,
                configs.user || defaultConfigs.user,
                configs.password || defaultConfigs.password);

            let headers = configs.headers || defaultConfigs.headers;
            if (headers) {
                for (let head in headers) {
                    client.setRequestHeader(head, headers[head]);
                }
            }

            client.send(data);
        });
    }
}