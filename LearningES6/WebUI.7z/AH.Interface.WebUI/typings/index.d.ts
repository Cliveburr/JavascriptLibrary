/// <reference path="globals/node/index.d.ts" />
/// <reference path="globals/webcomponents.js/index.d.ts" />
