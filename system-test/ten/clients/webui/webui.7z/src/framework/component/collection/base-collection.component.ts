import { Component } from "@angular/core";
import { BaseComponent } from "../base.component";

@Component({
    template: ''
})
export abstract class BaseCollectionComponent extends BaseComponent {
    
}