import { InjectionToken } from "@angular/core";

export const SECURITY_MODAL = new InjectionToken<any>('SECURITY_MODAL');
