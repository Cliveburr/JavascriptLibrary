import { Directive } from "@angular/core";

@Directive({
    selector: '[t-drop-icon]'
})
export class DropIconDirective {
}
